/* -------------------------------------------------------------------------------- /
	
	Magentech jQuery
	Created by Magentech
	v1.0 - 20.9.2016
	All rights reserved.

	+----------------------------------------------------+
		TABLE OF CONTENTS
	+----------------------------------------------------+
	[1]		Home page 5
	[2]		Home page 6
	[3]		Home page 8
	
/ -------------------------------------------------------------------------------- */

/* ---------------------------------------------------
	1.Home page 1
-------------------------------------------------- */

/* ---------------------------------------------------
	Listing Tabs - Slider
-------------------------------------------------- */

/* ---------------------------------------------------
	1.Home page 5
-------------------------------------------------- */

/* ---------------------------------------------------
	2.Home page 6
-------------------------------------------------- */

// function setCookie(cname, cvalue, exdays) {
// 	var d = new Date();
// 	console.log(d.getTime());
// 	d.setTime(d.getTime() + (exdays*24*60*60*1000));
// 	var expires = "expires="+d.toUTCString();
// 	document.cookie = cname + "=" + cvalue + "; " + expires;
// }
// function getCookie(cname) {
// 	var name = cname + "=";
// 	var ca = document.cookie.split(';');
// 	for(var i=0; i<ca.length; i++) {
// 		var c = ca[i];
// 		while (c.charAt(0)==' ') c = c.substring(1);
// 		if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
// 	}
// 	return "";
// }
// function checkCookie() {
// 	var check_cookie = getCookie("so_newletter_custom_popup");
// 	if(check_cookie == ""){
// 		setCookie("so_newletter_custom_popup", "Newletter Popup", 1 );
// 	}
// }

// owlCarousel:
// -------------------------------------------
$(document).ready(function($) {
	// $(".carouselHero").owlCarousel({
	// 	items: 1,
	// 	loop: true,
	// 	nav: true
	// });
})